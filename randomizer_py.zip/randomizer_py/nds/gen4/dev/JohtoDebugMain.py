from nds.buffer import Buffer
from nds.gen4.JohtoWarpRandomizer import HeartGoldSoulSilverRandomizerFunctions
from nds.tableLocator import TableLocator
import ndspy.rom

# rom = ndspy.rom.NintendoDSRom.fromFile('../HeartGold.nds')
# locator = TableLocator(rom)
# locator.get_table('mapHeaders')
random = HeartGoldSoulSilverRandomizerFunctions()
random.load_map_data()




