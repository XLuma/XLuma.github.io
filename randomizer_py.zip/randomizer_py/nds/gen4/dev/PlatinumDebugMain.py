from nds.buffer import Buffer
from nds.gen4.PlatinumWarpRandomizer import PlatinumRandomizerFunctions
from nds.tableLocator import TableLocator
import ndspy.rom

# rom = ndspy.rom.NintendoDSRom.fromFile('Platinum.nds')
# locator = TableLocator(rom)
# locator.get_table('mapHeaders')
random = PlatinumRandomizerFunctions()
random.load_map_data()




