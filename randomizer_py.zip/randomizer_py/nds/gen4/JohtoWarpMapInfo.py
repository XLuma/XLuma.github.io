class WT:
    def __init__(self, warp_id, flag):
        if isinstance(warp_id, int) and isinstance(flag, int):
            self.warp_id = warp_id
            self.flag = flag
        else:
            raise ValueError("Invalid Warp Tuple")


# Event/HM Dependencies
# Any Warp/Connection that has an Event/HM Dependency will have a corresponding blocker flag
# Based off bits set in flag, we will know what dependencies are required to traverse
ROCKSMASH_FLAG = 0
KURT_FLAG = 1
CUT_FLAG = 2
BIKE_FLAG = 3
RADIOTOWER1_FLAG = 4
STRENGTH_FLAG = 5
SURF_FLAG = 6
LAKEOFRAGE_FLAG = 7
ROCKETHQ_FLAG = 8
WHIRLPOOL_FLAG = 9
RADIOTOWER2_FLAG = 10
WATERFALL_FLAG = 11
KANTO_FLAG = 12

END_FLAG = KANTO_FLAG

rocksmash_event = ['Map_Violet_City_Gym_00', 'Map_Route_36',
                   'Map_Sprout_Tower_Room00_02']  # also applies to miracle seed guy on route 32
kurt_event = ['Map_Azalea_Town_Room04_00']  # this is kurt's house
cut_event = ['Map_Slowpoke_Well_Room00_01', 'Map_Ilex_Forest_Room00_00:0', 'Map_Azalea_Town_Gym_00',
             'Map_Violet_City_Gym_00']
bike_event = ['Map_Goldenrod_City_Room01_00']  # this is the bike shop
radiotower1_event = ['Map_Radio_Tower_Room00_00']
strength_event = ['Map_Radio_Tower_Room00_00', 'Map_Goldenrod_City_Room05_00', 'Map_Route_42:0',
                  'Map_Goldenrod_City_Gym_00', 'Map_Azalea_Town_Gym_00',
                  'Map_Violet_City_Gym_00']  # also applies to sudowoodo roadblocks
surf_event = ['Map_Ecruteak_City_Room04_00', 'Map_Burned_Tower_Room00_01', 'Map_Ecruteak_City_Gym_00',
              'Map_Goldenrod_City_Gym_00', 'Map_Azalea_Town_Gym_00', 'Map_Violet_City_Gym_00']
lakeofrage_event = ['Map_Cianwood_City_Room04_00', 'Map_Lighthouse_Room00_06', 'Map_Lake_of_Rage',
                    'Map_Olivine_City_Gym_00', 'Map_Cianwood_City_Gym_00', 'Map_Ecruteak_City_Gym_00',
                    'Map_Goldenrod_City_Gym_00', 'Map_Azalea_Town_Gym_00', 'Map_Violet_City_Gym_00']  # unsure if you are required to go to the mahogany gift shop before entering rocket hq
rockethq_event = ['Map_Team_Rocket_HQ_Room00_02:0', 'Map_Team_Rocket_HQ_Room00_02:4', 'Map_Team_Rocket_HQ_Room00_03:0',
                  'Map_Team_Rocket_HQ_Room00_03:2']  # also grants access to whirlpool
whirlpool_event = ['Map_Mahogany_Town_Gym_02', 'Map_Olivine_City_Gym_00', 'Map_Cianwood_City_Gym_00',
                   'Map_Ecruteak_City_Gym_00', 'Map_Goldenrod_City_Gym_00', 'Map_Azalea_Town_Gym_00',
                   'Map_Violet_City_Gym_00']
radiotower2_event = ['Map_Mahogany_Town_Gym_02:0', 'Map_Olivine_City_Gym_00', 'Map_Cianwood_City_Gym_00',
                     'Map_Radio_Tower_Room00_04:0', 'Map_Radio_Tower_Room00_00', 'Map_Goldenrod_City_Room00_04',
                     'Map_Radio_Tower_Room00_05']
waterfall_event = ['Map_Ice_Path_Room00_00:0', 'Map_Ice_Path_Room00_00:3', 'Map_Dragons_Den_Room00_02',
                   'Map_Blackthorn_City_Gym_00', 'Map_Mahogany_Town_Gym_02', 'Map_Olivine_City_Gym_00',
                   'Map_Cianwood_City_Gym_00', 'Map_Ecruteak_City_Gym_00', 'Map_Goldenrod_City_Gym_00',
                   'Map_Azalea_Town_Gym_00', 'Map_Violet_City_Gym_00']
kanto_event = ['Map_Bell_Tower_Room00_09', 'Map_Whirl_Islands_Room00_06', 'Map_Blackthorn_City_Gym_00',
               'Map_Mahogany_Town_Gym_02', 'Map_Olivine_City_Gym_00', 'Map_Cianwood_City_Gym_00',
               'Map_Ecruteak_City_Gym_00', 'Map_Goldenrod_City_Gym_00', 'Map_Azalea_Town_Gym_00',
               'Map_Violet_City_Gym_00']

FORCED_FLAG_ORDER = [ROCKSMASH_FLAG, CUT_FLAG, STRENGTH_FLAG, SURF_FLAG, WHIRLPOOL_FLAG, WATERFALL_FLAG, KANTO_FLAG]
FLAG_EVENT_LIST = [rocksmash_event, kurt_event, cut_event, bike_event, radiotower1_event, strength_event, surf_event,
                   lakeofrage_event, rockethq_event, whirlpool_event, radiotower2_event, waterfall_event,
                   kanto_event]  # incomplete

no_event_allowed = []  # incomplete
map_chain_breaks = []  # incomplete

# Event Based Warps and Warp Connections
# If map not specified, assume that all warps are accessible
map_warp_accessibility = {
    'Map_Route_26': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Route_27': {
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Route_31': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_New_Bark_Town': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0)],
    },
    'Map_Cherrygrove_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0)],
    },
    'Map_Route_32': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Violet_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(9, 0), WT(10, 0)],
        9: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(10, 0)],
        10: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0)],
    },
    'Map_Azalea_Town': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
    },
    'Map_Route_34': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Goldenrod_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        9: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        10: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        11: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        12: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        13: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        14: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0), WT(15, 0), WT(16, 0)],
        15: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(16, 0)],
        16: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
    },
    'Map_Route_35': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Route_36': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    'Map_Ecruteak_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(9, 0), WT(10, 0),
            WT(11, 0)],
        9: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(10, 0),
            WT(11, 0)],
        10: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(11, 0)],
        11: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0)],
    },
    'Map_Cianwood_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
    },
    'Map_Olivine_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(8, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(8, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0)],
    },
    'Map_Route_41': {
        0: [WT(1, 576), WT(2, 576), WT(3, 576)],
        1: [WT(0, 576), WT(2, 576), WT(3, 576)],
        2: [WT(0, 576), WT(1, 576), WT(3, 576)],
        3: [WT(0, 576), WT(1, 576), WT(2, 576)],
    },
    'Map_Route_42': {
        0: [WT(1, 0), WT(2, 0), WT(3, 64), WT(5, 64)],
        1: [WT(0, 0), WT(2, 0), WT(3, 64), WT(5, 64)],
        2: [WT(0, 0), WT(1, 0), WT(3, 64), WT(5, 64)],
        3: [WT(0, 64), WT(1, 64), WT(2, 64), WT(5, 64)],
        5: [WT(0, 64), WT(1, 64), WT(2, 64), WT(3, 64)],
    },
    'Map_Route_43': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    'Map_Mahogany_Town': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    'Map_Lake_of_Rage': {
        0: [WT(1, 68)],
        1: [WT(0, 68)]
    },
    'Map_Route_46': {
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Blackthorn_City': {
        0: [WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(2, 2112)],
        1: [WT(0, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(2, 2112)],
        2: [WT(0, 2112), WT(1, 2112), WT(3, 2112), WT(4, 2112), WT(5, 2112), WT(6, 2112), WT(7, 2112)],
        3: [WT(0, 0), WT(1, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(2, 2112)],
        4: [WT(0, 0), WT(1, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(2, 2112)],
        5: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(2, 2112)],
        6: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(2, 2112)],
        7: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(2, 2112)],
    },
    'Map_Route_2': {
        0: [WT(1, 0), WT(2, 4), WT(3, 4)],
        1: [WT(0, 0), WT(2, 4), WT(3, 4)],
        2: [WT(3, 0), WT(0, 4), WT(1, 4)],
        3: [WT(2, 0), WT(0, 4), WT(1, 4)],
    },
    'Map_Route_28': {
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Viridian_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
    },
    # 'Map_Indigo_Plateau': {
    # },
    # 'Map_Mount_Silver': {
    # },
    'Map_Route_6': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Route_11': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Vermilion_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(6, 64)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(6, 64)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(6, 64)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(6, 64)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(7, 0), WT(6, 64)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(7, 0), WT(6, 64)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 64)],
    },
    'Map_Saffron_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        9: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        10: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        11: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        12: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(13, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        13: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(14, 0), WT(15, 0), WT(16, 0)],
        14: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0), WT(15, 0), WT(16, 0)],
        15: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(16, 0)],
        16: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
    },
    'Map_Route_5': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Route_10': {
        0: [WT(1, 64), WT(2, 0)],
        1: [WT(0, 64), WT(2, 64)],
        2: [WT(0, 0), WT(1, 64)]
    },
    'Map_Cerulean_City': {  # todo take care of cerulean cave
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
    },
    # 'Map_Route_8': {
    # },
    'Map_Route_12': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    # 'Map_Route_15': {
    # },
    'Map_Lavender_Town': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
    },
    # 'Map_Route_7': {
    # },
    'Map_Celadon_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(5, 4)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(5, 4)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(5, 4)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(6, 0), WT(5, 4)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(6, 0), WT(5, 4)],
        5: [WT(0, 4), WT(1, 4), WT(2, 4), WT(3, 4), WT(4, 4), WT(6, 4)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 4)],
    },
    'Map_Route_16_Room02_00': {
        0: [WT(1, 0), WT(2, 4)],
        1: [WT(0, 0), WT(2, 4)],
        2: [WT(0, 4), WT(1, 4)],
    },
    # 'Map_Route_16': {
    # },
    # 'Map_Route_18': {
    # },
    'Map_Fuchsia_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0), WT(10, 0)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(9, 0), WT(10, 0)],
        9: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(10, 0)],
        10: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0)],
    },
    # 'Map_Route_3': {
    # },
    'Map_Pewter_City': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    'Map_Route_2_Room00_00': {
        0: [WT(1, 0), WT(2, 4), WT(3, 4), WT(4, 4), WT(5, 4)],
        1: [WT(0, 0), WT(2, 4), WT(3, 4), WT(4, 4), WT(5, 4)],
        2: [WT(3, 0), WT(4, 0), WT(5, 0), WT(0, 4), WT(1, 4)],
        3: [WT(2, 0), WT(4, 0), WT(5, 0), WT(0, 4), WT(1, 4)],
        4: [WT(2, 0), WT(3, 0), WT(5, 0), WT(0, 4), WT(1, 4)],
        5: [WT(2, 0), WT(3, 0), WT(4, 0), WT(0, 4), WT(1, 4)],
    },
    'Map_Pallet_Town': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    # 'Map_Route_19': {
    # },
    # 'Map_Route_20': {
    # },
    'Map_Route_47': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Safari_Zone_Gate': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Ruins_of_Alph_Room00_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(8, 0), WT(9, 0), WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0),
            WT(14, 0), WT(5, 64)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(8, 0), WT(9, 0), WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0),
            WT(14, 0), WT(5, 64)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(8, 0), WT(9, 0), WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0),
            WT(14, 0), WT(5, 64)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(8, 0), WT(9, 0), WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0),
            WT(14, 0), WT(5, 64)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(8, 0), WT(9, 0), WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0),
            WT(14, 0), WT(5, 64)],
        5: [WT(0, 64), WT(1, 64), WT(2, 64), WT(3, 64), WT(4, 64), WT(8, 64), WT(9, 64), WT(10, 64), WT(11, 64),
            WT(12, 64), WT(13, 64), WT(14, 64)],
        6: [WT(5, 0), WT(15, 0), WT(0, 64), WT(1, 64), WT(2, 64), WT(3, 64), WT(4, 64), WT(8, 64), WT(9, 64),
            WT(10, 64), WT(11, 64), WT(12, 64), WT(13, 64), WT(14, 64)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(9, 0), WT(10, 0), WT(12, 0), WT(14, 0), WT(5, 64)],
        9: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(8, 0), WT(10, 0), WT(11, 0), WT(13, 0), WT(5, 64)],
        10: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(8, 0), WT(9, 0), WT(11, 0), WT(12, 0), WT(13, 0),
             WT(14, 0), WT(5, 64)],
        11: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(9, 0), WT(10, 0), WT(12, 0), WT(14, 0), WT(5, 64)],
        12: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(8, 0), WT(10, 0), WT(11, 0), WT(13, 0), WT(5, 64)],
        13: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(9, 0), WT(10, 0), WT(12, 0), WT(14, 0), WT(5, 64)],
        14: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(8, 0), WT(10, 0), WT(11, 0), WT(13, 0), WT(5, 64)],
        15: [WT(5, 0), WT(6, 0), WT(0, 64), WT(1, 64), WT(2, 64), WT(3, 64), WT(4, 64), WT(8, 64), WT(9, 64),
             WT(10, 64), WT(11, 64), WT(12, 64), WT(13, 64), WT(14, 64)],
    },
    'Map_Digletts_Cave_Room00_00': {
        2: [WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    'Map_Mount_Moon_Room00_00': {
        0: [WT(1, 0), WT(2, 0), WT(5, 0)],
        1: [WT(0, 0), WT(2, 0), WT(5, 0)],
        2: [WT(0, 0), WT(1, 0), WT(5, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    # 'Map_Mount_Moon_Room00_01': {
    # },
    'Map_Mount_Moon_Room00_02': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    # 'Map_Rock_Tunnel_Room00_00': {
    # },
    'Map_Rock_Tunnel_Room00_01': {
        0: [WT(1, 0), WT(4, 0), WT(5, 0)],
        1: [WT(0, 0), WT(4, 0), WT(5, 0)],
        2: [WT(3, 0), WT(6, 0), WT(7, 0)],
        3: [WT(2, 0), WT(6, 0), WT(7, 0)],
        4: [WT(0, 0), WT(1, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(4, 0)],
        6: [WT(2, 0), WT(3, 0), WT(7, 0)],
        7: [WT(2, 0), WT(3, 0), WT(6, 0)],
    },
    # 'Map_Pal_Park_Room00_00': {
    # },
    'Map_Sprout_Tower_Room00_00': {
        0: [WT(1, 0), WT(5, 0)],
        1: [WT(0, 0), WT(5, 0)],
        2: [WT(3, 0), WT(4, 0), WT(6, 0)],
        3: [WT(2, 0), WT(4, 0), WT(6, 0)],
        4: [WT(2, 0), WT(3, 0), WT(6, 0)],
        5: [WT(0, 0), WT(1, 0)],
        6: [WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    # 'Map_Sprout_Tower_Room00_01': {
    # },
    'Map_Bell_Tower_Room00_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Bell_Tower_Room00_01': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Bell_Tower_Room00_02': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Bell_Tower_Room00_03': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
    },
    'Map_Bell_Tower_Room00_04': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
        3: [WT(1, 0), WT(4, 0)],
        4: [WT(1, 0), WT(3, 0)],
    },
    'Map_Bell_Tower_Room00_05': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Bell_Tower_Room00_06': {
        0: [WT(1, 0), WT(4, 0)],
        1: [WT(0, 0), WT(4, 0)],
        4: [WT(0, 0), WT(1, 0)],
    },
    'Map_Bell_Tower_Room00_07': {
        0: [WT(1, 0)],
        1: [WT(0, 0)],
        2: [WT(4, 0)],
        4: [WT(2, 0)],
    },
    'Map_Bell_Tower_Room00_08': {
        2: [WT(6, 0), WT(7, 0)],
        3: [WT(4, 0), WT(5, 0)],
        4: [WT(3, 0), WT(5, 0)],
        5: [WT(3, 0), WT(4, 0)],
        6: [WT(2, 0), WT(7, 0)],
        7: [WT(2, 0), WT(6, 0)],
    },
    'Map_National_Park_Room00_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0)],
    },
    'Map_National_Park_Room00_01': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0)],
    },
    'Map_Radio_Tower_Room00_01': {
        0: [WT(1, 512)],
        1: [WT(0, 0)]
    },
    'Map_Radio_Tower_Room00_02': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Radio_Tower_Room00_03': {
        0: [WT(1, 0)],
        1: [WT(0, 0)],
        2: [WT(3, 0)],
        3: [WT(4, 0)]
    },
    'Map_Radio_Tower_Room00_04': {
        1: [WT(2, 0)],
        2: [WT(1, 0)]
    },
    'Map_Union_Cave_Room00_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 64)],
        1: [WT(0, 0), WT(2, 0), WT(3, 64)],
        2: [WT(0, 0), WT(1, 0), WT(3, 64)],
        3: [WT(0, 64), WT(1, 64), WT(2, 64)],
    },
    'Map_Union_Cave_Room00_01': {
        0: [WT(3, 64), WT(4, 96)],
        3: [WT(0, 64), WT(4, 32)],
        4: [WT(3, 32), WT(0, 96)],
    },
    'Map_Union_Cave_Room00_02': {
        1: [WT(3, 64)],
        2: [WT(4, 0)],
        3: [WT(1, 64)],
        4: [WT(2, 0)]
    },
    'Map_Slowpoke_Well_Room00_01': {
        0: [WT(1, 96)],
        1: [WT(0, 96)]
    },
    'Map_Lighthouse_Room00_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Lighthouse_Room00_01': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Lighthouse_Room00_03': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
        3: [WT(4, 0), WT(5, 0)],
        4: [WT(3, 0), WT(5, 0)],
        5: [WT(3, 0), WT(4, 0)],
    },
    'Map_Lighthouse_Room00_04': {
        1: [WT(2, 0), WT(3, 0)],
        2: [WT(1, 0), WT(3, 0)],
        3: [WT(1, 0), WT(2, 0)],
    },
    'Map_Lighthouse_Room00_05': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Team_Rocket_HQ_Room00_02': {
        0: [WT(1, 0)],
        1: [WT(0, 0)],
        3: [WT(4, 0)],
        4: [WT(3, 0)]
    },
    'Map_Team_Rocket_HQ_Room00_03': {
        0: [WT(3, 0)],
        1: [WT(2, 0)],
        2: [WT(1, 0)],
        3: [WT(0, 0)]
    },
    'Map_Ilex_Forest_Room00_00': {
        0: [WT(1, 0), WT(2, 4), WT(3, 4), WT(4, 4), WT(5, 4)],
        1: [WT(0, 0), WT(2, 4), WT(3, 4), WT(4, 4), WT(5, 4)],
        2: [WT(3, 0), WT(4, 0), WT(5, 0), WT(0, 4), WT(1, 4)],
        3: [WT(2, 0), WT(4, 0), WT(5, 0), WT(0, 4), WT(1, 4)],
        4: [WT(2, 0), WT(3, 0), WT(5, 0), WT(0, 4), WT(1, 4)],
        5: [WT(2, 0), WT(3, 0), WT(4, 0), WT(0, 4), WT(1, 4)],
    },
    'Map_Goldenrod_Tunnel_Room00_00': {
        0: [WT(2, 0), WT(6, 0), WT(7, 0)],
        1: [WT(3, 0), WT(8, 0), WT(9, 0)],
        2: [WT(0, 0), WT(6, 0), WT(7, 0)],
        3: [WT(1, 0), WT(8, 0), WT(9, 0)],
        6: [WT(0, 0), WT(2, 0), WT(7, 0)],
        7: [WT(0, 0), WT(2, 0), WT(6, 0)],
        8: [WT(1, 0), WT(3, 0), WT(9, 0)],
        9: [WT(1, 0), WT(3, 0), WT(8, 0)],
    },
    'Map_Goldenrod_Tunnel_Room00_01': {
        0: [WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        1: [WT(0, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        2: [WT(0, 0), WT(1, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(5, 0), WT(6, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(6, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
    },
    'Map_Goldenrod_City_Room00_02': {
        0: [WT(1, 1024)],
        1: [WT(0, 1024)]
    },
    # 'Map_Mount_Mortar_Room00_00': {  # todo fix this
    # },
    'Map_Mount_Mortar_Room00_01': {
        0: [WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        1: [WT(0, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        3: [WT(0, 0), WT(1, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        4: [WT(0, 0), WT(1, 0), WT(3, 0), WT(5, 0), WT(6, 0)],
        5: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(6, 0)],
        6: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        7: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0)],
        8: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(9, 0)],
        9: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0)],
    },
    # 'Map_Mount_Mortar_Room00_02': {
    # },
    'Map_Mount_Mortar_Room00_03': {
        0: [WT(3, 0), WT(1, 96), WT(2, 96)],
        1: [WT(2, 0), WT(0, 96), WT(3, 96)],
        2: [WT(1, 0), WT(0, 96), WT(3, 96)],
        3: [WT(0, 0), WT(1, 96), WT(2, 96)],
    },
    'Map_Route_26_Room00_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Bellchime_Trail_Room10_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Ecruteak_City_Room01_00': {
        0: [WT(1, 64)],
        1: [WT(0, 0)]
    },
    'Map_Ecruteak_City_PokemonCenter00_00': {
        0: [WT(2, 0)],
        2: [WT(0, 0)],
    },
    'Map_Cerulean_Cave_Room00_00': {
        0: [WT(1, 64), WT(3, 64), WT(4, 64), WT(6, 64), WT(8, 64), WT(9, 64), WT(10, 64), WT(11, 64), WT(13, 64),
            WT(14, 64)],
        1: [WT(9, 0), WT(0, 64), WT(3, 64), WT(4, 64), WT(6, 64), WT(8, 64), WT(10, 64), WT(11, 64), WT(13, 64),
            WT(14, 64)],
        2: [WT(0, 64), WT(1, 64), WT(3, 64), WT(4, 64), WT(6, 64), WT(8, 64), WT(9, 64), WT(10, 64), WT(11, 64),
            WT(13, 64), WT(14, 64)],
        3: [WT(0, 0), WT(4, 0), WT(6, 0), WT(8, 0), WT(10, 0), WT(11, 0), WT(13, 0), WT(14, 0), WT(1, 64), WT(9, 64)],
        4: [WT(0, 0), WT(3, 0), WT(6, 0), WT(8, 0), WT(10, 0), WT(11, 0), WT(13, 0), WT(14, 0), WT(1, 64), WT(9, 64)],
        5: [WT(7, 0), WT(12, 0)],
        6: [WT(0, 0), WT(3, 0), WT(4, 0), WT(8, 0), WT(10, 0), WT(11, 0), WT(13, 0), WT(14, 0), WT(1, 64), WT(9, 64)],
        7: [WT(5, 0), WT(12, 0)],
        8: [WT(0, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(10, 0), WT(11, 0), WT(13, 0), WT(14, 0), WT(1, 64), WT(9, 64)],
        9: [WT(1, 0), WT(0, 64), WT(3, 64), WT(4, 64), WT(6, 64), WT(8, 64), WT(10, 64), WT(11, 64), WT(13, 64),
            WT(14, 64)],
        10: [WT(0, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(8, 0), WT(11, 0), WT(13, 0), WT(14, 0), WT(1, 64), WT(9, 64)],
        11: [WT(0, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(8, 0), WT(10, 0), WT(13, 0), WT(14, 0), WT(1, 64), WT(9, 64)],
        12: [WT(5, 0), WT(7, 0)],
        13: [WT(0, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(8, 0), WT(10, 0), WT(11, 0), WT(14, 0), WT(1, 64), WT(9, 64)],
        14: [WT(0, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(8, 0), WT(10, 0), WT(11, 0), WT(13, 0), WT(1, 64), WT(9, 64)],
    },
    # 'Map_Cerulean_Cave_Room00_01': {
    # },
    'Map_Cerulean_Cave_Room00_02': {
        0: [WT(3, 0), WT(1, 64), WT(2, 64)],
        1: [WT(2, 0), WT(0, 64), WT(3, 64)],
        2: [WT(1, 0), WT(0, 64), WT(3, 64)],
        3: [WT(0, 0), WT(1, 64), WT(2, 64)],
    },
    'Map_Seafoam_Islands_Room00_00': {
        0: [WT(2, 0), WT(4, 0), WT(5, 0)],
        2: [WT(0, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(2, 0), WT(5, 0)],
        5: [WT(0, 0), WT(2, 0), WT(4, 0)],
    },
    'Map_Seafoam_Islands_Room00_01': {
        0: [WT(1, 32), WT(2, 32), WT(3, 32), WT(4, 32), WT(5, 32)],
        1: [WT(0, 32), WT(2, 32), WT(3, 32), WT(4, 32), WT(5, 32)],
        2: [WT(3, 0), WT(4, 0), WT(0, 32), WT(1, 32), WT(5, 32)],
        3: [WT(2, 0), WT(4, 0), WT(0, 32), WT(1, 32), WT(5, 32)],
        4: [WT(2, 0), WT(3, 0), WT(0, 32), WT(1, 32), WT(5, 32)],
        5: [WT(0, 32), WT(1, 32), WT(2, 32), WT(3, 32), WT(4, 32)],
    },
    'Map_Seafoam_Islands_Room00_02': {
        1: [WT(0, 0), WT(8, 0), WT(10, 0)],
        2: [WT(0, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0)],
        3: [WT(7, 0), WT(11, 0)],
        4: [WT(0, 0), WT(2, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0)],
        5: [WT(0, 0), WT(2, 0), WT(4, 0), WT(6, 0), WT(8, 0), WT(9, 0)],
        6: [WT(0, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(8, 0), WT(9, 0)],
        7: [WT(3, 0), WT(11, 0)],
        9: [WT(0, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0)],
        10: [WT(0, 0), WT(1, 0), WT(8, 0)],
        11: [WT(3, 0), WT(7, 0)],
    },
    'Map_Seafoam_Islands_Room00_03': {
        0: [WT(5, 0), WT(6, 0), WT(8, 0), WT(11, 0)],
        1: [WT(4, 0), WT(10, 0)],
        2: [WT(7, 0), WT(12, 0)],
        3: [WT(9, 0), WT(13, 0)],
        4: [WT(1, 0), WT(10, 0)],
        5: [WT(0, 0), WT(6, 0), WT(8, 0), WT(11, 0)],
        6: [WT(0, 0), WT(5, 0), WT(8, 0), WT(11, 0)],
        7: [WT(2, 0), WT(12, 0)],
        8: [WT(0, 0), WT(5, 0), WT(6, 0), WT(11, 0)],
        9: [WT(3, 0), WT(13, 0)],
        10: [WT(1, 0), WT(4, 0)],
        11: [WT(0, 0), WT(5, 0), WT(6, 0), WT(8, 0)],
        12: [WT(2, 0), WT(7, 0)],
        13: [WT(3, 0), WT(9, 0)],
    },
    'Map_Seafoam_Islands_Room00_04': {
        0: [WT(11, 0), WT(5, 64), WT(10, 64)],
        3: [WT(8, 0), WT(4, 64), WT(9, 64)],
        4: [WT(9, 0), WT(3, 64), WT(8, 64)],
        5: [WT(10, 0), WT(0, 64), WT(11, 64)],
        8: [WT(3, 0), WT(4, 64), WT(9, 64)],
        9: [WT(4, 0), WT(3, 64), WT(8, 64)],
        10: [WT(5, 0), WT(0, 64), WT(11, 64)],
        11: [WT(0, 0), WT(5, 64), WT(10, 64)],
    },
    'Map_Viridian_Forest_Room00_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    # 'Map_Dark_Cave_Room00_00': {
    # },
    'Map_Dark_Cave_Room00_01': {
        0: [WT(1, 64), WT(2, 96)],
        1: [WT(0, 64), WT(2, 96)],
        2: [WT(0, 33), WT(1, 97)],
    },
    'Map_Goldenrod_City_Room04_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Goldenrod_City_Room09_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Goldenrod_City_Room09_01': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Goldenrod_City_Room09_02': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Goldenrod_City_Room09_03': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Goldenrod_City_Room09_04': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Ice_Path_Room00_00': {
        0: [WT(2, 0)],
        1: [WT(3, 0)],
        2: [WT(0, 0)],
        3: [WT(1, 0)]
    },
    'Map_Ice_Path_Room00_01': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
        3: [WT(4, 0), WT(5, 0)],
        4: [WT(3, 0), WT(5, 0)],
        5: [WT(3, 0), WT(4, 0)],
    },
    'Map_Ice_Path_Room00_02': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
        3: [WT(4, 0), WT(5, 0)],
        4: [WT(3, 0), WT(5, 0)],
        5: [WT(3, 0), WT(4, 0)],
    },
    'Map_Ice_Path_Room00_03': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Olivine_City_Room00_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Mahogany_Town_Room00_00': {
        0: [WT(1, 128)],
        1: [WT(0, 0)]
    },
    'Map_Whirl_Islands_Room00_00': {
        0: [WT(1, 0), WT(2, 0)],
        5: [WT(6, 0), WT(7, 64)],
        6: [WT(5, 0), WT(7, 64)],
        7: [WT(5, 64), WT(6, 64)],
    },
    'Map_Whirl_Islands_Room00_01': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        2: [WT(3, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        3: [WT(2, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        7: [WT(2, 0), WT(3, 0), WT(8, 0), WT(11, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        8: [WT(2, 0), WT(3, 0), WT(7, 0), WT(11, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        9: [WT(10, 0), WT(12, 0), WT(13, 0), WT(2, 32), WT(3, 32)],
        10: [WT(9, 0), WT(12, 0), WT(13, 0), WT(2, 32), WT(3, 32)],
        11: [WT(2, 0), WT(3, 0), WT(7, 0), WT(8, 0), WT(9, 32), WT(10, 32), WT(12, 32), WT(13, 32)],
        12: [WT(9, 0), WT(10, 0), WT(13, 0), WT(2, 32), WT(3, 32)],
        13: [WT(9, 0), WT(10, 0), WT(12, 0), WT(2, 32), WT(3, 32)],
    },
    'Map_Whirl_Islands_Room00_03': {
        2: [WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    'Map_Dragons_Den_Room00_01': {
        0: [WT(1, 0), WT(2, 576)],
        1: [WT(0, 0), WT(2, 576)],
        2: [WT(0, 576), WT(1, 576)],
    },
    'Map_Pokemon_League_Room00_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Tohjo_Falls_Room00_00': {
        0: [WT(1, 2112), WT(2, 2112)],
        1: [WT(0, 2112), WT(2, 2112)],
        2: [WT(0, 2112), WT(1, 2112)],
    },
    # 'Map_Cliff_Edge_Gate_Room00_00': {
    # },
    'Map_Pokeathlon_Dome': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Pokeathlon_Dome_Room00_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Victory_Road_Room00_00': {
        0: [WT(1, 32), WT(2, 32)],
        1: [WT(2, 0), WT(0, 32)],
        2: [WT(1, 0), WT(0, 32)],
    },
    'Map_Victory_Road_Room00_01': {
        0: [WT(3, 0), WT(4, 0), WT(7, 32), WT(8, 32)],
        3: [WT(0, 0), WT(4, 0), WT(7, 32), WT(8, 32)],
        4: [WT(0, 0), WT(3, 0), WT(7, 32), WT(8, 32)],
        5: [WT(6, 0), WT(0, 32), WT(3, 32), WT(4, 32), WT(7, 32), WT(8, 32)],
        6: [WT(5, 0), WT(0, 32), WT(3, 32), WT(4, 32), WT(7, 32), WT(8, 32)],
        7: [WT(8, 0), WT(0, 32), WT(3, 32), WT(4, 32)],
        8: [WT(7, 0), WT(0, 32), WT(3, 32), WT(4, 32)],
    },
    'Map_Victory_Road_Room00_02': {
        0: [WT(1, 0), WT(5, 0)],
        1: [WT(0, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0)],
    },
    'Map_Pokemon_League_Room01_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Pokemon_League_Room02_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Pokemon_League_Room03_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Pokemon_League_Room04_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_SS_Aqua_Room02_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(12, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(12, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(12, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(12, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(12, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(12, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0), WT(12, 0)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(9, 0), WT(12, 0)],
        9: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(12, 0)],
        12: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0)],
    },
    # 'Map_SS_Aqua_Room02_02': {
    # },
    # 'Map_SS_Aqua_Room02_03': {
    # },
    # 'Map_SS_Aqua_Room02_04': {
    # },
    # 'Map_SS_Aqua_Room02_05': {
    # },
    'Map_SS_Aqua_Room02_06': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Olivine_City_Room00_01': {
        0: [WT(1, 0)],
        1: [WT(0, 0)]
    },
    'Map_Ruins_of_Alph_Room01_10': {
        0: [WT(1, 0)],
        1: [WT(0, 0)],
        2: [WT(3, 0)],
        3: [WT(2, 0)]
    },
    'Map_Bell_Tower_Room00_11': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Cliff_Cave_Room00_00': {
        0: [WT(3, 0), WT(4, 0), WT(6, 0)],
        1: [WT(7, 0), WT(8, 0)],
        3: [WT(0, 0), WT(4, 0), WT(6, 0)],
        4: [WT(0, 0), WT(3, 0), WT(6, 0)],
        6: [WT(0, 0), WT(3, 0), WT(4, 0)],
        7: [WT(1, 0), WT(8, 0)],
        8: [WT(1, 0), WT(7, 0)],
    },
    # 'Map_Vermilion_City_Room00_02': {
    # },
    'Map_Saffron_City_Room05_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    # 'Map_Saffron_City_Room06_00': {
    # },
    'Map_Route_35_Room01_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Celadon_City_Room00_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Celadon_City_Room00_01': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Celadon_City_Room00_02': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Celadon_City_Room00_03': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Celadon_City_Room00_04': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Celadon_City_Room01_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Celadon_City_Room01_03': {
        0: [WT(2, 0)],
        2: [WT(0, 0)]
    },
    'Map_Battle_Frontier': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(7, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        7: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(8, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        8: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(9, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        9: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(10, 0),
            WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        10: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        11: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(12, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        12: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(13, 0), WT(14, 0), WT(15, 0)],
        13: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(14, 0), WT(15, 0)],
        14: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0), WT(15, 0)],
        15: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0), WT(7, 0), WT(8, 0), WT(9, 0),
             WT(10, 0), WT(11, 0), WT(12, 0), WT(13, 0), WT(14, 0)],
    },
    'Map_Battle_Frontier_Room00_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    'Map_Battle_Tower_Room01_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Battle_Factory_Room02_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Battle_Hall_Room03_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Battle_Castle_Room04_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Battle_Arcade_Room05_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Global_Terminal_Room11_00': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Frontier_Access_Room00_01': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0), WT(6, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0), WT(6, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(6, 0)],
        6: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
    },
    'Map_Route_5_Room01_01': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0), WT(4, 0), WT(5, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0), WT(4, 0), WT(5, 0)],
        4: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(5, 0)],
        5: [WT(0, 0), WT(1, 0), WT(2, 0), WT(3, 0), WT(4, 0)],
    },
    'Map_Route_5_Room01_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Route_6_Room00_00': {
        0: [WT(1, 0), WT(2, 0), WT(3, 0)],
        1: [WT(0, 0), WT(2, 0), WT(3, 0)],
        2: [WT(0, 0), WT(1, 0), WT(3, 0)],
        3: [WT(0, 0), WT(1, 0), WT(2, 0)],
    },
    'Map_Saffron_City_Gym_00': {
        2: [WT(3, 0), WT(16, 0), WT(17, 0)],
        3: [WT(2, 0), WT(16, 0), WT(17, 0)],
        4: [WT(5, 0), WT(24, 0), WT(25, 0)],
        5: [WT(4, 0), WT(24, 0), WT(25, 0)],
        6: [WT(7, 0), WT(20, 0), WT(21, 0)],
        7: [WT(6, 0), WT(20, 0), WT(21, 0)],
        8: [WT(9, 0), WT(28, 0), WT(29, 0)],
        9: [WT(8, 0), WT(28, 0), WT(29, 0)],
        10: [WT(11, 0), WT(22, 0), WT(23, 0)],
        11: [WT(10, 0), WT(22, 0), WT(23, 0)],
        12: [WT(13, 0), WT(18, 0), WT(19, 0)],
        13: [WT(12, 0), WT(18, 0), WT(19, 0)],
        14: [WT(15, 0), WT(26, 0), WT(27, 0)],
        15: [WT(14, 0), WT(26, 0), WT(27, 0)],
        16: [WT(2, 0), WT(3, 0), WT(17, 0)],
        17: [WT(2, 0), WT(3, 0), WT(16, 0)],
        18: [WT(12, 0), WT(13, 0), WT(19, 0)],
        19: [WT(12, 0), WT(13, 0), WT(18, 0)],
        20: [WT(6, 0), WT(7, 0), WT(21, 0)],
        21: [WT(6, 0), WT(7, 0), WT(20, 0)],
        22: [WT(10, 0), WT(11, 0), WT(23, 0)],
        23: [WT(10, 0), WT(11, 0), WT(22, 0)],
        24: [WT(4, 0), WT(5, 0), WT(25, 0)],
        25: [WT(4, 0), WT(5, 0), WT(24, 0)],
        26: [WT(14, 0), WT(15, 0), WT(27, 0)],
        27: [WT(14, 0), WT(15, 0), WT(26, 0)],
        28: [WT(8, 0), WT(9, 0), WT(29, 0)],
        29: [WT(8, 0), WT(9, 0), WT(28, 0)],
    },
    # 'Map_Mount_Silver_Cave_Room00_00': {
    # },
    'Map_Mount_Silver_Cave_Room00_01': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    'Map_Mount_Silver_Cave_Room00_02': {
        0: [WT(1, 0), WT(2, 0)],
        1: [WT(0, 0), WT(2, 0)],
        2: [WT(0, 0), WT(1, 0)],
    },
    # 'Map_Mount_Silver_Cave_Room00_05': {
    # },
    # 'Map_Mount_Silver_Cave_Room00_06': {
    # },
    # 'Map_Sinjoh_Ruins_Room00_00': {
    # },
    # 'Map_Mount_Moon_Room00_03': {
    # },
}

# TODO Fill Out Later

map_to_map_warp_accessibility = {

}

cant_go_back_warps = {
    'Map_Pokemon_League_Room01_00': [0],
    'Map_Pokemon_League_Room02_00': [0],
    'Map_Pokemon_League_Room03_00': [0],
    'Map_Pokemon_League_Room04_00': [0],
}

# Handles Connection Requirements
rocksmash_needed = [  # TODO make work

]
cut_needed = [  # TODO make work
    'Map_Route_32'
]
surf_needed = [  # TODO make work
    'Map_Route_40', 'Map_Route_41'
]
strength_or_spraypail_needed = [  # TODO make work
    'Map_Route_36'
]
bike_needed = [

]
whirlpool_needed = [

]

# TODO finish work
dont_randomize = [
    'Map_New_Bark_Town_Room00_00', 'Map_New_Bark_Town_Room01_01', 'Map_New_Bark_Town_Room02_00',
    'Map_New_Bark_Town_Room03_01', 'Map_New_Bark_Town_Room00_01', 'Map_Route_30_Room00_00', 'Map_Azalea_Town_Gym_01',
    'Map_Mahogany_Town_Gym_01', 'Map_Mahogany_Town_Gym_00', 'Map_Saffron_City_Room06_02', 'Map_ROTOMs_Room',
    'Map_Goldenrod_City_Room09_06', 'Map_Celadon_City_Room00_06',
    # 'Map_Celadon_City_Room01_05',  # this breaks things, is an elevator which like all others points to Map_None as a dummy destination
    'Map_Celadon_City_Room01_06',
    'Map_Lighthouse_Room00_07',
    'Map_Battle_Frontier_Room00_00',
    'Map_Frontier_Access_Room00_01',
    'Map_Battle_Frontier',
    'Map_Safari_Zone_Gate_Room00_00',
    'Map_Pal_Park_Room01_00',
    'Map_Pal_Park_Room00_00',
    'Map_New_Bark_Town_Room01_01',
    'Map_New_Bark_Town_Room03_01',
    'Map_Battle_Tower',
    'Map_Battle_Factory',
    'Map_Battle_Hall',
    'Map_Battle_Castle',
    'Map_Battle_Arcade',
    'Map_Safari_Zone_Room00_01'  # this is like some weird map in the safari zone that points to Map_None as well, no clue what's going on here until I can get DSPRE going
]

dont_randomize_warp = {  # TODO finish work
    'Map_Saffron_City_Room06_00': [1],
    'Map_Ecruteak_City_PokemonCenter00_00': [1]
}

not_needed = [  # TODO finish work, this likely is partially incorrect thanks to ends containing some maps which it shouldn't/missing some that it should
    'Map_New_Bark_Town_Room00_00', 'Map_New_Bark_Town_Room01_01', 'Map_New_Bark_Town_Room02_00',
    'Map_New_Bark_Town_Room03_01', 'Map_New_Bark_Town_Room00_01',
    'Map_Goldenrod_City_PokemonCenter00_01',
    'Map_Goldenrod_City_Special00_00', 'Map_Goldenrod_City_Room04_02', 'Map_Goldenrod_City_Room03_00',
    'Map_Goldenrod_City_Room02_00', 'Map_Goldenrod_City_Room07_00', 'Map_Goldenrod_City_Room08_00',
    'Map_Azalea_Town_PokemonCenter00_01', 'Map_Azalea_Town_Room01_00',
    'Map_Azalea_Town_Mart00_00', 'Map_Slowpoke_Well_Room00_02',
    'Map_Ruins_of_Alph_Room01_11', 'Map_Ruins_of_Alph_Room01_12', 'Map_Ruins_of_Alph_Room01_14',
    'Map_Ruins_of_Alph_Room01_13', 'Map_Ruins_of_Alph_Room01_04', 'Map_Ruins_of_Alph_Room01_15',
    'Map_Ruins_of_Alph_Room00_01', 'Map_Ruins_of_Alph_Room01_17', 'Map_Route_32_PokemonCenter00_01',
    'Map_Route_34_Room00_00', 'Map_Pokeathlon_Dome', 'Map_Pokeathlon_Dome_Room00_06', 'Map_Pokeathlon_Dome_Room00_01',
    'Map_Pokeathlon_Dome_Room01_00', 'Map_Ecruteak_City_Room03_00',
    'Map_Ecruteak_City_Room07_00', 'Map_Mystery_Zone',
    'Map_Ecruteak_City_PokemonCenter00_04', 'Map_Ecruteak_City_Mart00_00', 'Map_Olivine_City_PokemonCenter00_01',
    'Map_Olivine_City_Mart00_00',
    'Map_Lighthouse_Room00_02', 'Map_Olivine_City_Room05_00', 'Map_Olivine_City_Room06_00',
    'Map_Olivine_City_Room02_00', 'Map_Olivine_City_Room04_00', 'Map_SS_Aqua_Room02_01', 'Map_Vermilion_City_Room00_00',
    'Map_Vermilion_City_PokemonCenter00_01', 'Map_Vermilion_City_Room02_00', 'Map_Vermilion_City_Room03_00',
    'Map_Vermilion_City_Mart00_00', 'Map_Vermilion_City_Room05_00',
    'Map_Route_12_Room00_00', 'Map_Seafoam_Islands_Room00_05', 'Map_Cinnabar_Island_PokemonCenter00_01',
    'Map_Pallet_Town_Room00_01', 'Map_Pallet_Town_Room01_01', 'Map_Pallet_Town_Room02_00',
    'Map_Viridian_City_Room01_00', 'Map_Viridian_City_Room02_01', 'Map_Viridian_City_Mart00_00',
    'Map_Viridian_City_PokemonCenter00_01', 'Map_Route_26_Room01_00', 'Map_Tohjo_Falls_Room00_01',
    'Map_Route_27_Room00_00', 'Map_Pokemon_League_Room06_00', 'Map_Pokemon_League_Room07_00', 'Map_Route_28_Room00_00',
    'Map_Mount_Silver_Cave_Room00_04', 'Map_Mount_Silver_Cave_Room00_03', 'Map_Mount_Silver_Cave_Room00_07',
    'Map_Mount_Silver_PokemonCenter00_01', 'Map_Route_2_Room01_00', 'Map_Pewter_City_Room00_00',
    'Map_Pewter_City_Room01_00', 'Map_Pewter_City_Mart00_00',
    'Map_Pewter_City_PokemonCenter00_01', 'Map_Pewter_City_Room05_00', 'Map_Cerulean_City_Room00_00',
    'Map_Cerulean_City_Room01_00', 'Map_Cerulean_City_Room02_00', 'Map_Cerulean_City_PokemonCenter00_01',
    'Map_Cerulean_City_Mart00_00', 'Map_Cerulean_City_Room03_00',
    'Map_Lavender_Town_PokemonCenter00_01', 'Map_Lavender_Town_Room01_00', 'Map_Lavender_Town_Room02_00',
    'Map_Lavender_Town_Room03_00', 'Map_Lavender_Town_Mart00_00', 'Map_Lavender_Town_Room05_00',
    'Map_Lavender_Town_Room06_00', 'Map_Power_Plant_Room01_00', 'Map_Route_10_PokemonCenter00_01',
    'Map_Saffron_City_Room05_02', 'Map_Saffron_City_Room07_01', 'Map_Saffron_City_Room06_00',
    'Map_Saffron_City_Room00_00', 'Map_Saffron_City_Mart00_00',
    'Map_Saffron_City_PokemonCenter00_01', 'Map_Saffron_City_Room04_00', 'Map_Celadon_City_Room01_01',
    'Map_Celadon_City_PokemonCenter00_01', 'Map_Celadon_City_Special00_00', 'Map_Celadon_City_Room04_00',
    'Map_Celadon_City_Room06_00', 'Map_Route_16_Room00_00', 'Map_Route_5_Room03_00',
    'Map_Route_25_Room00_00', 'Map_Mount_Moon_Mart00_00', 'Map_Route_3_PokemonCenter00_01',
    'Map_Fuchsia_City_Mart00_00', 'Map_Pal_Park_Room01_00', 'Map_Fuchsia_City_Room03_00',
    'Map_Fuchsia_City_PokemonCenter00_01', 'Map_Fuchsia_City_Room05_00', 'Map_Battle_Tower_Room01_00',
    'Map_Battle_Factory_Room02_00', 'Map_Battle_Hall_Room03_00', 'Map_Battle_Castle_Room04_00',
    'Map_Battle_Arcade_Room05_00', 'Map_Frontier_Access_PokemonCenter00_01', 'Map_Frontier_Access_Mart00_00',
    'Map_Frontier_Access_Room00_02', 'Map_Whirl_Islands_Room00_05',
    'Map_Cianwood_City_PokemonCenter00_01',
    'Map_Cianwood_City_Room01_00', 'Map_Cianwood_City_Room06_00', 'Map_Cianwood_City_Room05_00',
    'Map_Embedded_Tower_Room00_00', 'Map_Embedded_Tower_Room00_01', 'Map_Embedded_Tower_Room00_02',
    'Map_Safari_Zone_Gate_Room00_00', 'Map_Safari_Zone_Gate_PokemonCenter00_01', 'Map_Cianwood_City_Room07_00',
    'Map_Lake_of_Rage_Room00_00', 'Map_Lake_of_Rage_Room01_00',
    'Map_Mahogany_Town_PokemonCenter00_01', 'Map_Mahogany_Town_Room01_00', 'Map_Blackthorn_City_Room01_00',
    'Map_Blackthorn_City_Room02_00',
    'Map_Blackthorn_City_Mart00_00', 'Map_Blackthorn_City_PokemonCenter00_01', 'Map_Blackthorn_City_Room05_00',
    'Map_Violet_City_Room02_00', 'Map_Violet_City_PokemonCenter00_01',
    'Map_Violet_City_Room03_00', 'Map_Violet_City_Room05_00', 'Map_Violet_City_Mart00_00', 'Map_Route_30_Room01_00',
    'Map_Route_30_Room00_00', 'Map_Cherrygrove_City_PokemonCenter00_01', 'Map_Cherrygrove_City_Mart00_00',
    'Map_Cherrygrove_City_Room02_00', 'Map_Cherrygrove_City_Room03_00', 'Map_Cherrygrove_City_Room04_00',
    'Map_Pal_Park_Room00_00', 'Map_Goldenrod_City_Room10_00', 'Map_Celadon_City_Room03_00',
    'Map_Celadon_City_Room01_03', 'Map_Celadon_City_Room01_04', 'Map_Goldenrod_City_Room09_06',
    'Map_Celadon_City_Room00_06'
]

non_navigable_connections = [  # TODO finish work

]

connection_to_connection_rules = {}

grouped_warps = {

}

other_overwrites = {

}

override_maps = [

]


def search_for_needed_maps(event_maps, accesible_maps):
    ret = True
    for req in event_maps:
        map_name = req
        warp_parts = []
        if ':' in req:
            map_name = req.split(':')[0]
            warp_parts = req.split(':')
        if map_name not in accesible_maps:
            ret = False
            break
        if len(warp_parts) != 0:
            original_length = len(warp_parts)
            for warp in accesible_maps[map_name]:
                if str(warp) in warp_parts:
                    warp_parts.remove(str(warp))
            if len(warp_parts) == original_length:
                ret = False
                break
    return ret


def check_progession_blockers(flag, accesible_maps):  # TODO make work
    for flag_num in range(len(FLAG_EVENT_LIST)):
        if flag_num == flag:
            return search_for_needed_maps(FLAG_EVENT_LIST[flag], accesible_maps)
    return False


# If warp_id = -1 we check connection, otherwise we check if there is an accessible warp from warp id
# noinspection DuplicatedCode
def is_map_progressable(map, accesible_maps, warp_id, ignore=False):  # TODO make work
    if not check_progession_blockers(SURF_FLAG, accesible_maps) and map in surf_needed:
        return False
    if not check_progession_blockers(ROCKSMASH_FLAG, accesible_maps) and map in rocksmash_needed:
        return False
    if not check_progession_blockers(CUT_FLAG, accesible_maps) and map in cut_needed:
        return False
    if not check_progession_blockers(BIKE_FLAG, accesible_maps) and map in bike_needed:
        return False
    if not check_progession_blockers(STRENGTH_FLAG, accesible_maps) and map in strength_or_spraypail_needed:
        return False
    if not check_progession_blockers(WHIRLPOOL_FLAG, accesible_maps) and map in whirlpool_needed:
        return False
    if warp_id == -1 and not ignore:
        if map not in map_warp_accessibility:
            return True
        map_warps = map_warp_accessibility[map].keys()
        for map_warp in map_warps:
            if is_map_progressable(map, accesible_maps, map_warp):
                return True
        return False
    if warp_id != -1:
        if map not in map_warp_accessibility:
            return True
        if warp_id not in map_warp_accessibility[map]:
            return True
        potential_warps = map_warp_accessibility[map][warp_id]
        if len(potential_warps) == 0:
            return True
        for potential_warp in potential_warps:
            bits = bin(potential_warp.flag)
            index = 0
            warp_pass = True
            for bit in reversed(bits):
                if bit == '1':
                    if not check_progession_blockers(index, accesible_maps):
                        warp_pass = False
                        break
                index = index + 1
            if warp_pass:
                return True
        return False
    else:
        return True


def is_warp_to_warp_valid(map, accesible_maps, from_warp_id, to_warp_id):
    if map not in map_warp_accessibility:
        return True  # If map doesn't specify warp routing all warps are accessible
    if from_warp_id not in map_warp_accessibility[map]:
        return False  # If warp id isnt in map specifications, warp is not meant to be randomized
    potential_warps = map_warp_accessibility[map][from_warp_id]
    for potential_warp in potential_warps:
        if potential_warp.warp_id != to_warp_id:
            continue
        bits = bin(potential_warp.flag)
        index = 0
        warp_pass = True
        for bit in reversed(bits):
            if bit == '1':
                if not check_progession_blockers(index, accesible_maps):
                    warp_pass = False
                    break
            index = index + 1
        if warp_pass:
            return True
    return False


def is_warp_ready(warp_tuple: WT, accesible_maps):
    bits = bin(warp_tuple.flag)
    index = 0
    warp_pass = True
    for bit in reversed(bits):
        if bit == '1':
            if not check_progession_blockers(index, accesible_maps):
                warp_pass = False
                break
        index = index + 1
    return warp_pass
